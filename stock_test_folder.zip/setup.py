from setuptools import setup, find_packages

def read_requirements(req_path):
    pack_list = []

    with open(req_path) as txt_file:
        for line in txt_file:
            pack_list.append(line.strip())
    
    return pack_list

package_list = read_requirements('requirements.txt')

setup(
    name = 'stockNN', 
    version = '0.1.0', 
    description = 'TBA', 
    author = 'Hogan Choi', 
    author_email = 'hogan.choi.03@gmail.com', 
    license = 'MIT', 
    packages = find_packages(where = 'src'), 
    package_dir = {'': 'src'}, 
    install_requires = package_list, 
    classifiers = [
        'Development Status :: 4 - Beta', 
        'Intended Audience :: Science/Research', 
        'License :: OSI Approved :: MIT License', 
        'Operating System :: OS Independent', 
        'Programming Language :: Python :: 3.10'
    ],    
)